#include <linux/version.h>
#include <linux/capability.h>
#include <linux/cred.h>
#include <linux/err.h>
#include <linux/fdtable.h>
#include <linux/file.h>
#include <linux/fs.h>
#include <linux/pid.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
// https://github.com/torvalds/linux/commit/8703e8a465b1e9cadc3680b4b1248f5987e54518
#include <linux/sched/user.h>
#include <linux/sched/task.h>
#endif
#include <linux/sched.h>
#include <linux/seccomp.h>
#include <linux/thread_info.h>
#include <linux/uidgid.h>
#include <linux/syscalls.h>
#include "objsec.h"
#include <linux/spinlock.h>
#include <linux/tty.h>
#include <linux/security.h>

#include "policy/allowlist.h"
#include "policy/app_profile.h"
#include "arch.h"
#include "compat/kernel_compat.h"
#include "klog.h" // IWYU pragma: keep
#include "selinux/selinux.h"
#include "infra/su_mount_ns.h"
#ifdef CONFIG_KSU_TRACEPOINT_HOOK
#include "hook/tp_marker.h"
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 7, 0)
static struct group_info root_groups = { .usage = REFCOUNT_INIT(2) };
#else
static struct group_info root_groups = { .usage = ATOMIC_INIT(2) };
#endif

static void setup_groups(struct root_profile *profile, struct cred *cred)
{
    if (profile->groups_count > KSU_MAX_GROUPS) {
        pr_warn("Failed to setgroups, too large group: %d!\n", profile->uid);
        return;
    }

    if (profile->groups_count == 1 && profile->groups[0] == 0) {
        // setgroup to root and return early.
        if (cred->group_info)
            put_group_info(cred->group_info);
        cred->group_info = get_group_info(&root_groups);
        return;
    }

    u32 ngroups = profile->groups_count;
    struct group_info *group_info = groups_alloc(ngroups);
    if (!group_info) {
        pr_warn("Failed to setgroups, ENOMEM for: %d\n", profile->uid);
        return;
    }

    int i;
    for (i = 0; i < ngroups; i++) {
        gid_t gid = profile->groups[i];
        kgid_t kgid = make_kgid(current_user_ns(), gid);
        if (!gid_valid(kgid)) {
            pr_warn("Failed to setgroups, invalid gid: %d\n", gid);
            put_group_info(group_info);
            return;
        }
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 9, 0)
        group_info->gid[i] = kgid;
#else
        GROUP_AT(group_info, i) = kgid;
#endif
    }

    groups_sort(group_info);
    set_groups(cred, group_info);
    put_group_info(group_info);
}

// https://github.com/rsuntk/KernelSU/blob/af9072e19d125a94797ae3c473e7e94c3d8c1bcc/kernel/app_profile.c#L79
void disable_seccomp(void)
{
    // https://github.com/backslashxx/KernelSU/tree/e28930645e764b9f0e5d0d1b0d5e236464939075/kernel/app_profile.c
    if (!current->seccomp.mode) {
        return;
    }

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 9, 0) || defined(KSU_OPTIONAL_SECCOMP_FILTER_RELEASE))
    struct task_struct *fake;
    fake = kmalloc(sizeof(*fake), GFP_ATOMIC);
    if (!fake) {
        pr_err("%s: cannot allocate fake struct!\n", __func__);
        return;
    }
#endif

    // Refer to kernel/seccomp.c: seccomp_set_mode_strict
    // When disabling Seccomp, ensure that current->sighand->siglock is held during the operation.
    spin_lock_irq(&current->sighand->siglock);
    // disable seccomp
#if defined(CONFIG_GENERIC_ENTRY) && LINUX_VERSION_CODE >= KERNEL_VERSION(5, 11, 0)
    clear_syscall_work(SECCOMP);
#else
    clear_thread_flag(TIF_SECCOMP);
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 9, 0) || defined(KSU_OPTIONAL_SECCOMP_FILTER_RELEASE))
    memcpy(fake, current, sizeof(*fake));
#endif
    current->seccomp.mode = 0;
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 9, 0) && !defined(KSU_OPTIONAL_SECCOMP_FILTER_RELEASE))
    // put_seccomp_filter is allowed while we holding sighand
    put_seccomp_filter(current);
#endif
    current->seccomp.filter = NULL;
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 7, 0) || defined(KSU_OPTIONAL_SECCOMP_FILTER_CNT))
    atomic_set(&current->seccomp.filter_count, 0);
#endif
    spin_unlock_irq(&current->sighand->siglock);

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 9, 0) || defined(KSU_OPTIONAL_SECCOMP_FILTER_RELEASE))
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 11, 0)
    // https://github.com/torvalds/linux/commit/bfafe5efa9754ebc991750da0bcca2a6694f3ed3#diff-45eb79a57536d8eccfc1436932f093eb5c0b60d9361c39edb46581ad313e8987R576-R577
    fake->flags |= PF_EXITING;
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(5, 11, 0)
    // https://github.com/torvalds/linux/commit/0d8315dddd2899f519fe1ca3d4d5cdaf44ea421e#diff-45eb79a57536d8eccfc1436932f093eb5c0b60d9361c39edb46581ad313e8987R556-R558
    fake->sighand = NULL;
#endif
    seccomp_filter_release(fake);
    kfree(fake);
#endif
}

int escape_with_root_profile(void)
{
    int ret = 0;
    struct cred *cred;
    // a bit useless, but we just want less ifdefs
    struct task_struct *p = current;
    struct task_struct *t;
    struct root_profile *profile = NULL;
    struct user_struct *new_user;

    cred = prepare_creds();
    if (!cred) {
        pr_warn("prepare_creds failed!\n");
        return -ENOMEM;
    }

    if (ksu_get_uid_t(current_euid()) == 0) {
        pr_warn("Already root, don't escape!\n");
        goto out_abort_creds;
    }

    if (test_thread_flag(TIF_KSU_DISABLE_ESCAPE_WITH_ROOT)) {
        pr_warn("TIF_KSU_DISABLE_ESCAPE_WITH_ROOT found, don't escape!\n");
        goto out_abort_creds;
    }

    profile = ksu_get_root_profile(ksu_get_uid_t(cred->uid));

    ksu_get_uid_t(cred->uid) = profile->uid;
    ksu_get_uid_t(cred->suid) = profile->uid;
    ksu_get_uid_t(cred->euid) = profile->uid;
    ksu_get_uid_t(cred->fsuid) = profile->uid;

    ksu_get_uid_t(cred->gid) = profile->gid;
    ksu_get_uid_t(cred->fsgid) = profile->gid;
    ksu_get_uid_t(cred->sgid) = profile->gid;
    ksu_get_uid_t(cred->egid) = profile->gid;
    cred->securebits = 0;

    BUILD_BUG_ON(sizeof(profile->capabilities.effective) != sizeof(kernel_cap_t));

    /*
     * Mirror the kernel set*uid path: update cred->user first, then
     * cred->ucounts, before commit_creds(). commit_creds() moves
     * RLIMIT_NPROC accounting based on cred->user; if uid changes while
     * user/ucounts stay stale, the old charge can remain pinned to the
     * previous UID.
     * See kernel/sys.c:set_user() and kernel/cred.c:set_cred_ucounts() /
     * commit_creds():
     * https://github.com/torvalds/linux/blob/v5.14/kernel/sys.c
     * https://github.com/torvalds/linux/blob/v5.14/kernel/cred.c
     */
#if defined(KSU_HAS_MODERN_ALLOC_UID) || LINUX_VERSION_CODE >= KERNEL_VERSION(3, 5, 0)
    new_user = alloc_uid(cred->uid);
#else
    new_user = alloc_uid(current_user_ns(), cred->uid);
#endif
    if (!new_user) {
        ret = -ENOMEM;
        goto out_abort_creds;
    }

    free_uid(cred->user);
    cred->user = new_user;

    // v5.14+ added cred->ucounts, so we must refresh it after changing uid/user:
    // https://github.com/torvalds/linux/commit/905ae01c4ae2ae3df05bb141801b1db4b7d83c61#diff-ff6060da281bd9ef3f24e17b77a9b0b5b2ed2d7208bb69b29107bee69732bd31
    // on older kernels, per-UID process accounting lives in user_struct.
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 14, 0)
    if (set_cred_ucounts(cred)) {
        goto out_abort_creds;
    }
#endif

    // setup capabilities
    // we need CAP_DAC_READ_SEARCH becuase `/data/adb/ksud` is not accessible for non root process
    // we add it here but don't add it to cap_inhertiable, it would be dropped automaticly after exec!
    u64 cap_for_ksud = profile->capabilities.effective | CAP_DAC_READ_SEARCH;
    memcpy(&cred->cap_effective, &cap_for_ksud, sizeof(cred->cap_effective));
    memcpy(&cred->cap_permitted, &profile->capabilities.effective, sizeof(cred->cap_permitted));
    memcpy(&cred->cap_bset, &profile->capabilities.effective, sizeof(cred->cap_bset));

    setup_groups(profile, cred);
    setup_selinux(profile->selinux_domain, cred);

    commit_creds(cred);

    disable_seccomp();

    if (profile->flags & FLAG_KSU_NO_NEW_PRIVS) {
        set_thread_flag(TIF_KSU_DISABLE_ESCAPE_WITH_ROOT);
    }

#ifdef CONFIG_KSU_TRACEPOINT_HOOK
    for_each_thread (p, t) {
        ksu_set_task_tracepoint_flag(t);
    }
#endif

    setup_mount_ns(profile->namespaces);
    ksu_put_root_profile(profile);
    return 0;

out_abort_creds:
    if (profile)
        ksu_put_root_profile(profile);
    abort_creds(cred);
    return ret;
}

void escape_to_root_for_init(void)
{
    struct cred *cred = prepare_creds();
    if (!cred) {
        pr_err("Failed to prepare init's creds!\n");
        return;
    }

    setup_selinux(KERNEL_SU_CONTEXT, cred);
    commit_creds(cred);
}
